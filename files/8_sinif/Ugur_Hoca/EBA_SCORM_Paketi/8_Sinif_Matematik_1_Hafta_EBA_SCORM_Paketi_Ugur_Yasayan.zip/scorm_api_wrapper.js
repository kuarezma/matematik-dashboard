/**
 * EBA (Eğitim Bilişim Ağı) & MEB SCORM 1.2 / 2004 Entegrasyon Adaptörü
 * T.C. Millî Eğitim Bakanlığı Standartlarında LMS İletişim Köprüsü
 */
(function() {
  'use strict';

  var SCORM_VERSION = null;
  var API = null;

  function findAPI(win) {
    var attempts = 0;
    while (win && !win.API && !win.API_1484_11 && win.parent && win.parent !== win && attempts < 10) {
      attempts++;
      win = win.parent;
    }
    if (win && win.API) {
      SCORM_VERSION = '1.2';
      return win.API;
    }
    if (win && win.API_1484_11) {
      SCORM_VERSION = '2004';
      return win.API_1484_11;
    }
    if (window.opener) {
      var op = window.opener;
      attempts = 0;
      while (op && !op.API && !op.API_1484_11 && op.parent && op.parent !== op && attempts < 10) {
        attempts++;
        op = op.parent;
      }
      if (op && op.API) {
        SCORM_VERSION = '1.2';
        return op.API;
      }
      if (op && op.API_1484_11) {
        SCORM_VERSION = '2004';
        return op.API_1484_11;
      }
    }
    return null;
  }

  window.ScormBridge = {
    initialized: false,
    terminated: false,
    api: null,
    score: 0,
    maxScore: 100,

    init: function() {
      if (this.initialized) return true;
      this.api = findAPI(window);
      if (!this.api) {
        console.log('[EBA SCORM] LMS API bulunamadı. Bağımsız Akıllı Tahta / Web modunda çalışıyor.');
        this.updateBadge('BAĞIMSIZ MOD');
        this.initialized = true;
        return false;
      }

      var res = false;
      if (SCORM_VERSION === '1.2') {
        res = (this.api.LMSInitialize('') === 'true' || this.api.LMSInitialize('') === true);
        if (res) {
          this.api.LMSSetValue('cmi.core.lesson_status', 'incomplete');
          this.api.LMSCommit('');
        }
      } else {
        res = (this.api.Initialize('') === 'true' || this.api.Initialize('') === true);
        if (res) {
          this.api.SetValue('cmi.completion_status', 'incomplete');
          this.api.Commit('');
        }
      }
      this.initialized = res;
      console.log('[EBA SCORM] LMS Bağlantısı Başarılı. SCORM Sürümü:', SCORM_VERSION);
      this.updateBadge('EBA LMS BAĞLI (' + SCORM_VERSION + ')');
      return res;
    },

    setScore: function(val, min, max) {
      if (min === undefined) min = 0;
      if (max === undefined) max = 100;
      this.score = val;
      this.maxScore = max;

      if (!this.api) {
        console.log('[EBA SCORM Standalone] Puan Kaydedildi:', val, '/', max);
        return;
      }

      if (SCORM_VERSION === '1.2') {
        this.api.LMSSetValue('cmi.core.score.raw', String(val));
        this.api.LMSSetValue('cmi.core.score.min', String(min));
        this.api.LMSSetValue('cmi.core.score.max', String(max));
        this.api.LMSCommit('');
      } else {
        this.api.SetValue('cmi.score.raw', String(val));
        this.api.SetValue('cmi.score.min', String(min));
        this.api.SetValue('cmi.score.max', String(max));
        this.api.SetValue('cmi.score.scaled', String((val / max).toFixed(2)));
        this.api.Commit('');
      }
      console.log('[EBA SCORM] Puan EBA\'ya iletildi:', val);
    },

    complete: function(finalScore) {
      if (finalScore !== undefined) {
        this.setScore(finalScore);
      }
      var scoreVal = this.score;
      var passed = (scoreVal >= 70);

      if (!this.api) {
        console.log('[EBA SCORM Standalone] Tamamlandı! Nihai Puan:', scoreVal, 'Durum:', passed ? 'GEÇTİ' : 'TAMAMLANDI');
        return;
      }

      if (SCORM_VERSION === '1.2') {
        var status = passed ? 'passed' : 'completed';
        this.api.LMSSetValue('cmi.core.lesson_status', status);
        this.api.LMSCommit('');
      } else {
        this.api.SetValue('cmi.completion_status', 'completed');
        this.api.SetValue('cmi.success_status', passed ? 'passed' : 'failed');
        this.api.Commit('');
      }
      console.log('[EBA SCORM] Tebrikler! Tamamlama durumu ve puan EBA platformuna başarıyla kaydedildi.');
    },

    terminate: function() {
      if (!this.api || this.terminated) return;
      if (SCORM_VERSION === '1.2') {
        this.api.LMSFinish('');
      } else {
        this.api.Terminate('');
      }
      this.terminated = true;
      console.log('[EBA SCORM] LMS Oturumu Kapatıldı.');
    },

    updateBadge: function(text) {
      var b = document.getElementById('ebaScormBadge');
      if (b) {
        b.textContent = '🇹🇷 ' + text;
      }
    }
  };

  window.addEventListener('load', function() {
    window.ScormBridge.init();
  });

  window.addEventListener('beforeunload', function() {
    window.ScormBridge.terminate();
  });
})();
